# SMARTBET ↔ Supabase

The site is wired to the **betting-platform schema** you supplied. Everything that
touches money, bets or the catalogue now goes through those tables and their
`SECURITY DEFINER` functions — there is no application-side balance column and no
trust in client-supplied odds.

| | |
|---|---|
| Project | `afnpkubogbmsgpwumrjf` |
| URL | `https://afnpkubogbmsgpwumrjf.supabase.co` |
| Publishable key | in `.env` as `SUPABASE_PUBLISHABLE_KEY` / `VITE_SUPABASE_PUBLISHABLE_KEY` |
| Secret (service role) key | **must be added by you** — see step 2 |

> The publishable key is safe in the browser. The **secret key is not**: it stays
> server-side only, never with a `VITE_` prefix, never committed.

---

## 1. Create the database (5 minutes)

Open **Supabase → SQL Editor** and run these four files from
`supabase/migrations/` **in order**. Each one is safe to re-run.

| # | File | What it does |
|---|---|---|
| 1 | `20260101000000_betting_platform_schema.sql` | Your schema, verbatim: enums, 28 tables, `place_bet`, `post_ledger_entry`, `settle_bet`, `settle_market`, `complete_deposit`, `request_withdrawal`, triggers, indexes and all RLS policies. |
| 2 | `20260101000100_smartbet_app_support.sql` | The additive things the web app needs on top of it (details below). |
| 3 | `20260101000200_seed_demo_catalogue.sql` | 12 fixtures / 34 markets / 78 prices so the site renders and bets are placeable immediately. |
| 4 | `20260101000300_booking_codes.sql` | Shareable booking codes: `booking_codes` + `booking_code_legs`, `create_booking_code()`, `load_booking_code()`, RLS. |
| 5 | `20260101000400_password_auth.sql` | Password sign-in support: a complete `handle_new_user()` (profile fields + username + wallet), INSERT protection on `profiles`, and the "own profile insert" policy. |
| 6 | `20260101000500_phone_login.sql` | Phone number as a second sign-in identifier: `normalize_login_phone()`, `resolve_phone_login()` (verifies the password against GoTrue's bcrypt hash), `login_attempts` throttling. |

> If the app reports `function public.load_booking_code(text) does not exist`
> straight after running file 4, PostgREST is holding a stale schema cache — run
> `notify pgrst, 'reload schema';` once.

### What file 2 adds (and why)

Nothing in your schema is altered or dropped — file 2 only adds:

1. **`profiles.national_id`** — the registration form collects a National ID / NIN;
   your schema had nowhere to put it before documents reach `kyc_documents`.
2. **`phone_otps`** — the phone-first signup flow stores its 6-digit codes here.
   RLS is on with no policies, so only the service-role key can read them.
3. **`app_settings.manual_deposits_enabled`** — the interim deposit switch (below).
4. **`deposits` INSERT policy + `claim_manual_deposit()`** — lets a signed-in player
   open and settle *their own pending* deposit while no payment provider exists.
   The policy pins `status = 'pending'`, so a client can never insert a completed
   deposit; crediting still only happens inside `complete_deposit()`.

> ⚠️ **Before you go live with a payment provider**, run:
> ```sql
> update app_settings set value = 'false' where key = 'manual_deposits_enabled';
> ```
> With the flag off, `claim_manual_deposit` raises and only the service role
> (your PSP webhook → `complete_deposit`) can settle a deposit.

## 2. Add the secret key (optional — sign-in does not need it)

Supabase → **Project Settings → API keys → secret key** (`sb_secret_…`), then:

```dotenv
SUPABASE_SERVICE_ROLE_KEY="sb_secret_…"
```

**Accounts, passwords and sign-in work without it** (see the authentication
section below). It is needed for: privileged deposit settlement, the audit-trail
row when a profile has to be created by hand, and the reserved phone-OTP signup
module (`phone_otps` + `auth.admin.createUser`). Without it, those specific flows
return a clear "the server is missing SUPABASE_SERVICE_ROLE_KEY" error instead of
failing silently.

## 3. Run the app

```sh
npm i          # or: bun install
npm run dev
```

Open the site, register with your email and a password, deposit, place a bet.

---

## Authentication (email + password, checked by Supabase)

Sign-in is **Supabase Auth**: the password is hashed with bcrypt and verified by
GoTrue, and the resulting JWT is attached as a bearer token to every server
function call (see `src/integrations/supabase/auth-attacher.ts`). No password,
hash or salt ever touches our own tables or server code.

| Action | Where | Supabase call |
|---|---|---|
| Register | `/auth` → Register | `auth.signUp({ email, password, options.data })` |
| Sign in (email) | `/auth` → Sign in | `auth.signInWithPassword({ email, password })` |
| Sign in (phone) | `/auth` → Sign in | `resolve_phone_login()` → then `auth.signInWithPassword({ email, password })` |
| Forgot password | `/auth` → Forgot password? | `auth.resetPasswordForEmail(email)` |
| Set/change password | `/auth` (recovery link, or signed in) | `auth.updateUser({ password })` |
| Resend confirmation | `/auth` (after registering) | `auth.resend({ type: 'signup', email })` |
| Sign out | account menu / `/auth` | `auth.signOut()` |

Registration collects full name, email, phone, National ID and date of birth;
they travel as auth metadata and the **`handle_new_user` trigger** copies them
into `profiles` (`first_name`, `last_name`, `phone`, `date_of_birth`,
`national_id`, `terms_accepted_at`) and creates the UGX wallet in the same
transaction — so a new account is immediately usable without any admin call.

### Signing in with a phone number as well as an email

The sign-in field takes **either** identifier — one account, one password:

```
Email address or phone number:   you@example.com    ←  or  →    0772 000 000
```

An email goes straight to Supabase. A phone number cannot (it is not an email, and
native phone auth would need the Phone provider plus an SMS gateway), so it takes
one extra step:

1. The browser calls the server function `resolvePhoneLogin`
   (→ SQL `resolve_phone_login(phone, password)`).
2. That function normalises the number (`0772 000 000` → `+256772000000`, the same
   rules as `modules/auth/phone.ts`), finds the account through `profiles.phone`,
   and verifies the typed password against GoTrue's own bcrypt hash in
   `auth.users.encrypted_password` using pgcrypto's `crypt()`.
3. On success it returns the account email, and the browser then signs in normally
   with `signInWithPassword` — so GoTrue verifies the password again and issues the
   session.

Why it is safe to expose with only the publishable key:

* **No enumeration.** The email is returned *only* alongside the correct password.
  An unknown number and a wrong password give the same empty result, and the
  "unknown number" path deliberately hashes a dummy so it takes the same time.
* **No brute-force bypass.** Failures are counted per phone number and refused
  after 8 in 15 minutes, so it cannot be used as an oracle that sidesteps GoTrue's
  own rate limits.
* **Ambiguous numbers are refused.** If two accounts share a number the resolver
  returns nothing and the player is told to use their email. Making the number
  unique removes that ambiguity — see the commented
  `create unique index profiles_phone_unique …` in file 6.
* The password does pass through one server function for the hash check. It is used
  only for that check, never logged, and never stored.

Requirements and limits:

* The number must be on `profiles.phone`. Every account registered after file 5 has
  it (the trigger copies it out of the auth metadata). **Accounts created before
  that** get it filled in on their next email sign-in by `getCurrentUserProfile`,
  so phone sign-in starts working for them afterwards.
* **Password reset stays email-only** — a reset link has to be delivered somewhere,
  so `/auth` asks for the account email there.
* Enabling Supabase's own Phone provider later is compatible with this; nothing
  here would change.

### Supabase dashboard settings that must match

**Authentication → Sign In / Providers**

* **Email** provider: enabled.
* **Confirm email**: your choice.
  * *Off* → registration signs the player straight in.
  * *On* → Supabase emails a link; the app shows a "Confirm email" screen with a
    resend button and blocks sign-in until it is clicked.
* **Minimum password length**: 8 (the app also enforces 8).
* **Site URL** and **Redirect URLs**: add `<your-site>/auth` (and
  `http://localhost:5173/auth` while developing) — the confirmation and
  password-reset links come back there. New Supabase projects allow the Site URL
  by default; a localhost URL is often **not** allowed until you add it.

### What is protected

* Pages that need an account (`/deposit`, `/withdraw`, `/my-bets`,
  `/my-bets/:id`, `/transactions`) render a sign-in panel via
  `components/require-auth.tsx` when there is no session.
* The bet slip, place-bet, deposits, withdrawals and booking-code creation all
  require the JWT; betting outside the app's own pages is refused by the database
  (`auth.uid()` is null → `place_bet` raises).
* `protect_profile_fields` forces `role`, `status` and `kyc_status` for any
  non-service-role INSERT **and** UPDATE, so a player can never promote
  themselves or mark their own KYC verified from the client.
* Local session storage is Supabase's own (localStorage, or the brokered preview
  storage when embedded); tokens refresh automatically.

### Testing the whole loop

1. Register at `/auth` with an email you can read. If confirmation is on, open
   the link, then sign in.
2. Check the profile and wallet the trigger created:
   ```sql
   select p.id, p.email, p.username, p.first_name, p.last_name, p.phone,
          p.date_of_birth, p.national_id, p.terms_accepted_at,
          w.currency, w.balance
   from profiles p left join wallets w on w.user_id = p.id
   order by p.created_at desc limit 3;
   ```
3. Sign out, then sign in again with the **phone number** you registered with and
   the same password — you should land back on the home page. The phone is
   normalised before it is looked up, so `0772 000 000`, `+256772000000` and
   `256 772 000 000` all work.
4. Sign out, then use **Forgot password?** and follow the emailed link back to
   `/auth` — you should land on the "Choose a new password" form.
5. Visit `/transactions` while signed out — you should get the sign-in panel, not
   an empty table.

Passwords appear only as a hash, and only to the auth service:

```sql
select id, email, email_confirmed_at,
       encrypted_password is not null as has_password,
       last_sign_in_at
from auth.users order by created_at desc limit 5;
```

Phone sign-in can be checked in SQL too (this is exactly what the app calls, with
the plain password):

```sql
select resolve_phone_login('0772 000 000', 'the-password');  -- → the account email
select resolve_phone_login('0772 000 000', 'wrong-password'); -- → no rows
select identifier, success, attempted_at from login_attempts   -- throttle log
order by attempted_at desc limit 20;
```

---

## Where each screen gets its data

| Screen | Source |
|---|---|
| `/auth` (register, sign in with email or phone, reset) | Supabase Auth `auth.users` + `resolve_phone_login()` for the phone path — see the authentication section above. |
| Home / Sports / Live / Match detail / Search | `events` + `leagues` + `sports` + `teams` + `markets` + `market_types` + `selections` via `getCatalogue()` (root loader → `CatalogueProvider`). Ids sent to the browser are the real UUIDs. |
| Bet slip → Place bet | `place_bet(p_stake, p_selection_ids)` — re-prices every leg, validates account/KYC/self-exclusion/stake limits, writes `bets` + `bet_legs`, debits the stake through `post_ledger_entry`. |
| My bets / Bet receipt | `bets` + `bet_legs` joined to `selections` / `markets` / `events` for labels (RLS: own rows only). The booking-style code shown is `SB` + the first 8 hex chars of the bet id, since the schema has no code column. |
| Header / account menu balance | `wallets.balance` |
| Transactions | `ledger_entries` (own rows, append-only, newest first, running balance) |
| Deposit | `createDeposit` → `deposits` row → `claim_manual_deposit()` / `complete_deposit()` |
| Withdraw | `requestWithdrawal` → `payment_methods` (masked label) → `request_withdrawal()`, which debits immediately and requires `kyc_status = 'verified'` |
| Booking codes | `create_booking_code()` (save the slip) and `load_booking_code()` (resolve a code for anyone, signed in or not) over `booking_codes` + `booking_code_legs` — see below. |

### Booking codes

A booking code is an 8-character shareable reference (`K7QM23XB`, alphabet without
`I`, `O`, `0`, `1`) that stores a snapshot of a bet slip. `/booking-code` can both
create and load them, and the bet slip has a "Create booking code" button.

* **Create** — `create_booking_code(p_selection_ids, p_stake)`, signed-in only. It
  re-reads every price from `selections`, applies the same validation as
  `place_bet` (active selection, open market, `max_bet_legs`, no two legs from one
  event, max 50 live codes per account) and stores the legs with the odds of the
  moment. The returned code is shown and copied in the UI.
* **Load** — `load_booking_code(p_code)` is callable by `anon` as well, so a
  shared slip opens for someone who has not registered yet. It returns each leg
  with the **current** price, the price when the code was created and an
  `is_available` flag computed with `place_bet`'s rules. Loading refreshes the
  slip; legs that have closed are reported to the player rather than silently
  dropped, and the slip's `bettable: false` guard refuses anything stale.
* **Privacy** — the code is the capability. `booking_codes` has **no** public
  SELECT policy, so codes cannot be listed or enumerated; only a caller who
  already holds a code can resolve it. Owners can read, list and revoke their own
  codes (delete policy), and nothing can be inserted directly by a client.
* **Expiry** — 7 days by default (`booking_codes.expires_at`). Expired codes
  return no rows.

```sql
-- Most-shared slips:
select code, leg_count, total_odds, load_count, created_at
from booking_codes order by load_count desc limit 20;

-- Delete long-expired codes (safe at any time):
delete from booking_codes where expires_at < now() - interval '30 days';
```

### Security properties

* The browser never sends odds, totals or payouts — only `selections.id` values
  and the stake. Prices are read inside the database function.
* `ledger_entries` is append-only (triggers block UPDATE/DELETE/TRUNCATE), and
  every movement carries an `idempotency_key` (`bet_stake:<bet_id>`,
  `deposit:<deposit_id>`, …) so a retry can never double-post.
* `protect_profile_fields` stops a player escalating their own `role`, `status`
  or `kyc_status` through the API.
* `post_ledger_entry`, `settle_bet`, `settle_market`, `complete_deposit` and
  `reject_withdrawal` are revoked from `anon`/`authenticated`: only the service
  role can call them.

### Demo fallback

If the catalogue query fails or the database has no fixtures yet, the UI renders
the local demo fixtures so pages are never blank. Those prices are marked
`bettable: false`, a notice explains why, and the bet slip **refuses to place**
them (they do not exist in the database).

---

## Operating the book

```sql
-- Verify a player so they can withdraw:
update profiles set kyc_status = 'verified' where id = '<user-uuid>';

-- Make someone staff (needed for the staff catalogue/audit RLS policies):
update profiles set role = 'admin' where id = '<user-uuid>';

-- Move a price (logged automatically into odds_history):
update selections set odds = 2.10 where id = '<selection-uuid>';

-- Settle a market (marks selections + legs and settles every affected bet):
select settle_market(
  '<market-uuid>',
  array['<winning-selection-uuid>']::uuid[],   -- winners
  array[]::uuid[]                              -- voids (optional)
);

-- Credit a wallet by hand (always through the ledger, never a raw balance update):
select post_ledger_entry(
  (select id from wallets where user_id = '<user-uuid>' and currency = 'UGX'),
  'adjustment', 50000, null, 'manual', 'manual:goodwill:<uuid>', 'Goodwill credit');
```

Settlement is deliberately **not** exposed in the UI: `settle_market` /
`settle_bet` are service-role functions, so your traders' back office (or an odds
feed callback) drives them.

---

## Not wired yet (deliberate scope)

* **Payment providers** — MTN MoMo / Airtel Money / card. Deposits run through the
  manual switch; withdrawals are recorded as `pending` and are paid out by staff
  (`reject_withdrawal` refunds instantly).
* **SMS / phone verification** — players can sign in with the phone number they
  registered (see above), but nothing *verifies* that a number belongs to them, and
  there is no OTP. `src/modules/auth/phone-auth.functions.ts` plus the `phone_otps`
  table are the ready-made path for adding SMS verification; they need an SMS
  gateway and the service-role key, and are not referenced by any UI.
* **Two-factor authentication** — Supabase supports TOTP MFA; nothing in the app
  enrols a factor yet.
* **KYC document upload** — `kyc_documents` + Supabase Storage is ready in the
  schema, but there is no upload UI yet; verify players with the SQL above.
* **Cash-out** — `bet_cashout` exists in the ledger enum; no UI/endpoint yet.
* **Live odds feed** — replace rows in `events` / `markets` / `selections`
  (matched on `events.external_id`); no frontend change is needed.

## Verifying the connection

```sql
select
  (select count(*) from sports)      as sports,        -- expect 8
  (select count(*) from events)      as events,        -- expect 12
  (select count(*) from markets)     as markets,       -- expect 34
  (select count(*) from selections)  as selections,    -- expect 78
  (select count(*) from auth.users)  as accounts,      -- one per registration
  (select count(*) from wallets)     as wallets,       -- one per account
  (select count(*) from profiles)    as profiles,      -- one per account
  (select count(*) from ledger_entries) as ledger_rows, -- grows with every movement
  (select count(*) from booking_codes)  as booking_codes;
```

Round-trip test for booking codes (create one in the UI first, then):

```sql
select code, leg_count, total_odds, load_count, expires_at from booking_codes;
select * from load_booking_code('<THE-CODE>');   -- one row per leg, live prices
```

---

## Notes for whoever picks this up

* `supabase/migrations/` is the source of truth for the database.
  `drizzle/` (and `drizzle.config.ts`) is **left over from the previous schema**
  and is no longer used by the app — nothing imports it.
* Authentication lives in `src/hooks/use-auth.ts` (all Supabase Auth calls),
  `src/routes/auth.tsx` (the screens), `src/modules/auth/auth.functions.ts`
  (profile/wallet upkeep) and `src/modules/auth/phone-login.functions.ts` (the
  phone → email resolution used by phone sign-in). Nothing else in the app reads or
  writes credentials.
* `src/integrations/supabase/types.ts` was written by hand from the schema above
  because the machine this was set up on had no network access. Once you have the
  Supabase CLI locally you can regenerate it:
  `supabase gen types typescript --project-id afnpkubogbmsgpwumrjf > src/integrations/supabase/types.ts`
* The default stake in the slip is UGX 2,000 and `app_settings.min_stake` is 500 —
  betting below the minimum is rejected by the database, not by the UI.
