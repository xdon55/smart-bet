# Smartbet

Sports betting front end (TanStack Start) backed by Supabase.

**Database setup, environment variables and operating notes: see
[SUPABASE_SETUP.md](./SUPABASE_SETUP.md).** It covers the three SQL files in
`supabase/migrations/`, the secret key you need to add, and how each screen maps
to a table.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4cf64c82-578f-4b08-b54e-8a88ef160285).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
